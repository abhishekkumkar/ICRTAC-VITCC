// Initialize routing
var routes = ["patrons", "speakers", "submissions", "timeline", "guidelines", "topics", "contact", "committees"]
router.init(routes)
